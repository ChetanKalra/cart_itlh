var localStorage = window.localStorage;

var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
        setCredentials();
    },



    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);

        console.log('Received Event: ' + id);
    }
};

document.getElementById("login").addEventListener("click", checkCredentials, false);

function setCredentials() {

    if (localStorage.getItem("Users") == "") {
        var Users = [];
        localStorage.setItem("Users", JSON.stringify(Users));
    } else {
        var Users = JSON.parse(localStorage.getItem("Users"));
    }
}

function checkCredentials() {

    if (localStorage.getItem("Users") == "") { var Users = []; } else {
        var Users = JSON.parse(localStorage.getItem("Users"));
    }

    var Size = Users.length;

    var userName = document.getElementById("userName").value;
    var pass = document.getElementById("pass").value;
    console.log("Size of users array is " + Size);
    for (var i = 0; i < Size; i++) {
        console.log(Users[i]);
        if (userName == Users[i].userName &&
            pass == Users[i].pass) {
            window.location = "dashboard.html";
        } else {
            console.log("you entered username = " + userName + " and password = " + pass + " which is incorrect");
        }

    }



}

app.initialize();