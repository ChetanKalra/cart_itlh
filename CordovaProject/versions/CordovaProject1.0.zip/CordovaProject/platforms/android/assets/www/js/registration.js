var localStorage = window.localStorage;

var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
        //setCredentials();
    },



    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        // var listeningElement = parentElement.querySelector('.listening');
        // var receivedElement = parentElement.querySelector('.received');

        // listeningElement.setAttribute('style', 'display:none;');
        // receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

document.getElementById("registerButton").addEventListener("click", registerUser, false);

function registerUser() {
    //alert("this function was called");
    if (localStorage.getItem("Users") == "") { var Users = []; } else {
        var Users = JSON.parse(localStorage.getItem("Users"));
    }

    var fullName = document.getElementById("fullName").value;
    var phoneNumber = document.getElementById("phoneNumber").value;
    var userName = document.getElementById("userName").value;
    var pass = document.getElementById("pass").value;

    var User = { fullName: fullName, userName: userName, pass: pass, phoneNumber: phoneNumber };

    Users.push(User);
    console.log(Users);
    localStorage.setItem("Users", JSON.stringify(Users));
    console.log(localStorage);

}

app.initialize();